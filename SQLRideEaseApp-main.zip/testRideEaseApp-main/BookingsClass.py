import sqlite3
import uuid
from Vehicle_Classes import Car, Van, Motorcycle

# Creation of User's Booking Information
class Booking:
    _customer_no = 1

    def __init__(self, user, pickup_location, dropoff_location, date_and_time, pax, vehicle, total_distance, total_cost, status, number=None, booking_id=None):
        if number is not None:
            self.no = number
            Booking._customer_no = max(Booking._customer_no, number + 1)
        else:
            self.no = Booking._customer_no
            Booking._customer_no += 1

        self.booking_id = booking_id if booking_id else str(uuid.uuid4())
        self.user = user
        self.pickup_location = pickup_location
        self.dropoff_location = dropoff_location
        self.date_and_time = date_and_time
        self.pax = pax
        self.vehicle = vehicle
        self.total_distance = total_distance
        self.total_cost = self.vehicle.calculate_cost(total_distance)
        self.status = status

    def to_dict(self):
        return {
            'Date and Time': self.date_and_time,
            'Customer No.': self.no,
            'ID': self.booking_id,
            'Name': self.user,
            'Vehicle': type(self.vehicle).__name__,
            'Pax': self.pax,
            'Pick Up Address': self.pickup_location,
            'Drop Off Address': self.dropoff_location,
            'Distance Travelled': self.total_distance,
            'Total Cost': self.total_cost,
            'Status': self.status
        }

    @staticmethod
    def save_to_db(booking, db_filename='bookings.db'):
        conn = sqlite3.connect(db_filename)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS bookings (
            booking_id TEXT PRIMARY KEY,
            user TEXT,
            pickup_location TEXT,
            dropoff_location TEXT,
            date_and_time TEXT,
            pax INTEGER,
            vehicle TEXT,
            total_distance REAL,
            total_cost REAL,
            status TEXT,
            customer_no INTEGER
        )''')
        c.execute('''INSERT INTO bookings (
            booking_id, user, pickup_location, dropoff_location, date_and_time, pax, vehicle, total_distance, total_cost, status, customer_no
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (
            booking.booking_id,
            booking.user,
            booking.pickup_location,
            booking.dropoff_location,
            booking.date_and_time,
            booking.pax,
            type(booking.vehicle).__name__,
            booking.total_distance,
            booking.total_cost,
            booking.status,
            booking.no
        ))
        conn.commit()
        conn.close()

    @staticmethod
    def delete_from_db(booking_id, db_filename='bookings.db'):
        conn = sqlite3.connect(db_filename)
        c = conn.cursor()
        c.execute('DELETE FROM bookings WHERE booking_id = ?', (booking_id,))
        conn.commit()
        conn.close()

    @staticmethod
    def from_db(booking_id, db_filename='bookings.db'):
        conn = sqlite3.connect(db_filename)
        c = conn.cursor()
        c.execute('SELECT * FROM bookings WHERE booking_id = ?', (booking_id,))
        row = c.fetchone()
        conn.close()
        if row:
            vehicle_map = {
                'Car': Car(),
                'Van': Van(),
                'Motorcycle': Motorcycle()
            }
            return Booking(
                booking_id=row[0],
                user=row[1],
                pickup_location=row[2],
                dropoff_location=row[3],
                date_and_time=row[4],
                pax=row[5],
                vehicle=vehicle_map[row[6]],
                total_distance=row[7],
                total_cost=row[8],
                status=row[9],
                number=row[10]
            )
        return None
