from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox, Treeview, Progressbar, Notebook
import tkinter.scrolledtext as scrolledtext
from tkinter import filedialog
from PIL import Image, ImageTk
import webbrowser
import sqlite3
import requests
from Vehicle_Classes import Vehicle, Motorcycle, Car, Van
from BookingsClass import Booking
from datetime import datetime

def booking_window_open():

    # ---------------------------------------------------------------------------- #
    #                                    BACKEND                                   #
    # ---------------------------------------------------------------------------- #

    api_key = "YOUR_API_KEY_HERE"  # Replace with your actual API key

    def get_distance(pickup_location, dropoff_location, api_key):
        url = "https://maps.googleapis.com/maps/api/distancematrix/json"
        params = {
            "origins": pickup_location,
            "destinations": dropoff_location,
            "key": api_key
        }
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            if data['status'] == 'OK':
                distance_value = data['rows'][0]['elements'][0]['distance']['value']  # in meters
                distance_km = round(distance_value / 1000, 2)  # convert to kilometers
                return distance_km
            else:
                raise ValueError(f"Error from API: {data['status']}")
        else:
            response.raise_for_status()

    def load_current_user():
        conn = sqlite3.connect('booking_system.db')
        cursor = conn.cursor()
        cursor.execute("SELECT username FROM current_user LIMIT 1")
        current_user = cursor.fetchone()
        conn.close()
        if current_user:
            return current_user[0]
        else:
            return None
    
    def on_closing(event):
        save_bookings()
        booking_window.destroy()

    # ---------------------------------------------------------------------------- #
    #                         FUNCTIONS FOR SWITCHING TABS                         #
    # ---------------------------------------------------------------------------- #

    def switch_to_home_tab():
        notebook.select(home_tab)

    def switch_to_booking_tab():
        notebook.select(booking_tab)

    def switch_to_booking_successful_tab():
        notebook.select(booking_successful_tab)

    def switch_to_bookings_list_tab():
        notebook.select(bookings_list_tab)

    # ---------------------------------------------------------------------------- #
    #                             FUNCTIONS FOR BUTTONS                            #
    # ---------------------------------------------------------------------------- #

    def motorcycle_button_clicked(event):
        global vehicle
        vehicle = Motorcycle()
        switch_to_booking_tab()

    def car_button_clicked(event):
        global vehicle
        vehicle = Car()
        switch_to_booking_tab()

    def van_button_clicked(event):
        global vehicle
        vehicle = Van()
        switch_to_booking_tab()
    
    def go_back_to_home_page_button_clicked(event):
        switch_to_home_tab()

    def view_bookings_list_button_clicked(event):
        switch_to_bookings_list_tab()

    def cancel_button_clicked(event):
        selected_item = bookings_treeview.focus()
        if selected_item:
            bookings_treeview.item(selected_item, values=("Cancelled",))
            cancel_booking()

    # ---------------------------------------------------------------------------- #
    #                       FUNCTIONS FOR VALIDATION OF INPUTS                     #
    # ---------------------------------------------------------------------------- #

    def is_address_valid(address):
        endpoint = 'https://maps.googleapis.com/maps/api/geocode/json'
        params = {
            'address': address,
            'key': api_key,
        }
        response = requests.get(endpoint, params=params)
        if response.status_code == 200:
            data = response.json()
            if data['status'] == 'OK':
                return True
            else:
                return False
        else:
            print(f"Error: {response.status_code}")
            return False

    def validate_pickup_address(pickup_address_entry):
        pickup_address = pickup_address_entry.get().strip()
        if not pickup_address:
            return False, "Please enter a pickup address."
        elif not is_address_valid(pickup_address):
            return False, "Pickup address not found or invalid."
        else:
            return True

    def validate_dropoff_address(dropoff_address_entry):
        dropoff_address = dropoff_address_entry.get().strip()
        if not dropoff_address:
            return False, "Please enter a dropoff address."
        elif not is_address_valid(dropoff_address):
            return False, "Dropoff address not found or invalid."
        else:
            return True

    def validate_passenger_amount(passengers):
        try:
            passenger_count = int(passengers)
        except ValueError:
            return False, "Passenger count should be a numeric value."

        if passenger_count <= 0:
            return False, "Passenger count should be a positive integer."

        if isinstance(vehicle, Car) and 4 < passenger_count <= 6:
            if not messagebox.askyesno("Confirmation", "The number of passengers exceeds the car's capacity. Are you sure you want to continue?", parent=booking_window):
                return False

        elif isinstance(vehicle, Van) and 10 < passenger_count <= 12:
            if not messagebox.askyesno("Confirmation", "The number of passengers exceeds the van's capacity. Are you sure you want to continue?", parent=booking_window):
                return False

        elif passenger_count > vehicle.capacity:
            return False, "The selected vehicle does not have enough capacity for the number of passengers."
    
        return True

    # ---------------------------------------------------------------------------- #
    #                             FUNCTIONS FOR BOOKING                            #
    # ---------------------------------------------------------------------------- #

    def book_now(username, pickup, dropoff, date_and_time, pax, vehicle_type, total_distance, total_cost, status):
        valid_pickup_location, pickup_msg = validate_pickup_address(pickup)
        valid_dropoff_location, dropoff_msg = validate_dropoff_address(dropoff)
        valid_passenger_amount, pax_msg = validate_passenger_amount(pax)

        if not valid_pickup_location:
            messagebox.showerror("Invalid Pick-up Address", pickup_msg, parent=booking_window)
            return False
        
        elif not valid_dropoff_location:
            messagebox.showerror("Invalid Drop off Address", dropoff_msg, parent=booking_window)
            return False
            
        elif not valid_passenger_amount:
            messagebox.showerror("Invalid Passenger Amount", pax_msg, parent=booking_window)
            return False
            
        else:
            booking = Booking(username, pickup, dropoff, date_and_time, vehicle_type, pax, total_distance, total_cost, status)
            add_booking_to_treeview(booking.to_dict())

            conn = sqlite3.connect('booking_system.db')
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO bookings (username, pickup, dropoff, date_and_time, vehicle_type, pax, total_distance, total_cost, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (username, pickup, dropoff, date_and_time, vehicle_type, pax, total_distance, total_cost, status))
            conn.commit()
            conn.close()
            messagebox.showinfo("Booking Successful", "Your booking has been successfully created.", parent=booking_window)

    def book_button_clicked(event):
        username = load_current_user()
        pickup = pickup_user_entry.get()
        dropoff = dropoff_user_entry.get()
        date_and_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        vehicle_type = vehicle.get_vehicle_type()
        pax = pax_user_entry.get()
        total_distance = get_distance(pickup_user_entry.get(), dropoff_user_entry.get(), api_key)
        total_cost = vehicle.calculate_cost(int(total_distance))
        status = "Ongoing"

        book_now(username, pickup, dropoff, date_and_time, pax, vehicle_type, total_distance, total_cost, status)
        
    def add_booking_to_treeview(booking_data):
        bookings_treeview.insert("", "end", values=(
            booking_data["username"], booking_data["pickup"], booking_data["dropoff"], booking_data["date_and_time"],
            booking_data["vehicle_type"], booking_data["pax"], booking_data["total_distance"], booking_data["total_cost"],
            booking_data["status"]
        ))

    # ---------------------------------------------------------------------------- #
    #        FUNCTIONS FOR CANCEL, SAVE, AND LOAD BOOKINGS IN A FILE               #
    # ---------------------------------------------------------------------------- #

    def cancel_booking():
        selected_item = bookings_treeview.focus()
        if selected_item:
            booking_data = bookings_treeview.item(selected_item)['values']
            booking_id = booking_data[0]  # Assuming the first column is the booking ID

            conn = sqlite3.connect('booking_system.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM bookings WHERE id=?", (booking_id,))
            conn.commit()
            conn.close()
            bookings_treeview.delete(selected_item)
            messagebox.showinfo("Booking Cancelled", "The booking has been successfully cancelled.", parent=booking_window)

    def save_bookings():
        conn = sqlite3.connect('booking_system.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM bookings")
        bookings = cursor.fetchall()
        conn.close()
        # Assuming bookings are stored in the database, no need to save to a file

    def load_bookings():
        conn = sqlite3.connect('booking_system.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM bookings")
        bookings = cursor.fetchall()
        conn.close()

        for booking in bookings:
            booking_data = {
                "username": booking[1],
                "pickup": booking[2],
                "dropoff": booking[3],
                "date_and_time": booking[4],
                "vehicle_type": booking[5],
                "pax": booking[6],
                "total_distance": booking[7],
                "total_cost": booking[8],
                "status": booking[9]
            }
            add_booking_to_treeview(booking_data)

    # ---------------------------------------------------------------------------- #
    #                                   FRONTEND                                   #
    # ---------------------------------------------------------------------------- #

    booking_window = Toplevel()
    booking_window.title("Ride Booking System")
    booking_window.iconbitmap("icons/RideEaseLogo.ico") 
    booking_window.resizable(False, False)

    booking_window.protocol("WM_DELETE_WINDOW", on_closing)

    notebook = Notebook(booking_window)
    notebook.pack(expand=True, fill='both')

    home_tab = Frame(notebook)
    booking_tab = Frame(notebook)
    booking_successful_tab = Frame(notebook)
    bookings_list_tab = Frame(notebook)

    notebook.add(home_tab, text="Home")
    notebook.add(booking_tab, text="Booking")
    notebook.add(booking_successful_tab, text="Booking Successful")
    notebook.add(bookings_list_tab, text="Bookings List")

    # Home Tab Widgets
    motorcycle_button = Button(home_tab, text="Motorcycle", command=lambda: motorcycle_button_clicked(None))
    car_button = Button(home_tab, text="Car", command=lambda: car_button_clicked(None))
    van_button = Button(home_tab, text="Van", command=lambda: van_button_clicked(None))

    motorcycle_button.pack(pady=10)
    car_button.pack(pady=10)
    van_button.pack(pady=10)

    # Booking Tab Widgets
    pickup_user_entry = Entry(booking_tab)
    dropoff_user_entry = Entry(booking_tab)
    pax_user_entry = Entry(booking_tab)

    pickup_user_label = Label(booking_tab, text="Pick-up Location")
    dropoff_user_label = Label(booking_tab, text="Drop-off Location")
    pax_user_label = Label(booking_tab, text="Number of Passengers")

    pickup_user_label.pack(pady=5)
    pickup_user_entry.pack(pady=5)
    dropoff_user_label.pack(pady=5)
    dropoff_user_entry.pack(pady=5)
    pax_user_label.pack(pady=5)
    pax_user_entry.pack(pady=5)

    book_button = Button(booking_tab, text="Book Now", command=lambda: book_button_clicked(None))
    book_button.pack(pady=20)

    # Bookings List Tab Widgets
    bookings_treeview = Treeview(bookings_list_tab, columns=("Username", "Pickup", "Dropoff", "Date and Time", "Vehicle Type", "Passengers", "Distance", "Cost", "Status"), show='headings')
    bookings_treeview.heading("Username", text="Username")
    bookings_treeview.heading("Pickup", text="Pickup")
    bookings_treeview.heading("Dropoff", text="Dropoff")
    bookings_treeview.heading("Date and Time", text="Date and Time")
    bookings_treeview.heading("Vehicle Type", text="Vehicle Type")
    bookings_treeview.heading("Passengers", text="Passengers")
    bookings_treeview.heading("Distance", text="Distance")
    bookings_treeview.heading("Cost", text="Cost")
    bookings_treeview.heading("Status", text="Status")

    bookings_treeview.pack(expand=True, fill='both')

    cancel_button = Button(bookings_list_tab, text="Cancel Booking", command=cancel_button_clicked)
    cancel_button.pack(pady=10)

    load_bookings()

    booking_window.mainloop()

booking_window_open()
