import sqlite3
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
import re
import string
from tkinter.scrolledtext import ScrolledText

current_signup_window = None

def signup_window_open(event=None):
    """Initialize and display the sign up window"""

    global current_signup_window
    if current_signup_window is not None:
        return

    def connect_db():
        # Connect to SQLite database
        conn = sqlite3.connect('Accounts.db')
        cursor = conn.cursor()
        # Create table if it doesn't exist
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                            username TEXT PRIMARY KEY,
                            password TEXT NOT NULL,
                            email TEXT NOT NULL
                        )''')
        conn.commit()
        return conn

    def signup(signup_username, signup_password, signup_email, signup_confirm, signup_gender, signup_terms, conn):
        # Validates signup information and creates a new user account if valid.
        valid_email, email_msg = validate_email_signup(signup_email)
        valid_username, username_msg = validate_username_signup(signup_username)
        valid_password, password_msg = validate_password_signup(signup_password)
        valid_confirm, confirm_msg = validate_confirmpw_signup(signup_confirm, signup_password)
        valid_gender, gender_msg = gender_option_picked(signup_gender)
        valid_terms, terms_msg = terms_and_conditions_checked(signup_terms)

        if not valid_email:
            messagebox.showerror("Invalid Email Address", email_msg, parent=current_signup_window)
            return False
        elif not valid_username:
            messagebox.showerror("Invalid Username", username_msg, parent=current_signup_window)
            return False
        elif not valid_password:
            messagebox.showerror("Invalid Password", password_msg, parent=current_signup_window)
            return False
        elif not valid_confirm:
            messagebox.showerror("Passwords do not match", confirm_msg, parent=current_signup_window)
            return False
        elif not valid_gender:
            messagebox.showerror("Selection Required.", gender_msg, parent=current_signup_window)
            return False
        elif not valid_terms:
            messagebox.showerror("Agreement Required", terms_msg, parent=current_signup_window)
            return False
        else:
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO users (username, password, email) VALUES (?, ?, ?)",
                               (signup_username, signup_password, signup_email))
                conn.commit()
                print(f"User '{signup_username}' signed up successfully!")
                messagebox.showinfo("Signup Successful", "Account created successfully!", parent=current_signup_window)
                current_signup_window.destroy()  # Close the signup window after signing up
            except sqlite3.IntegrityError:
                messagebox.showerror("Username Taken", "This username is already taken. Please choose another.", parent=current_signup_window)

    def signup_clicked():
        # Retrieves signup information from entry fields and calls the signup function.
        email = signup_email_entry.get()
        username = signup_user_entry.get()
        password = signup_password_entry.get()
        confirm = signup_confirm_entry.get()
        gender = signup_gender_var.get()
        terms = terms_var.get()

        signup(username, password, email, confirm, gender, terms, conn)

    def validate_username_signup(username):
        # Validates the username for signup.
        if len(username) < 4 or len(username) > 20 or username == "Username":
            return False, "Username must be between 4 and 20 characters"
        if not username.isalnum():
            return False, "Username can only contain alphanumeric characters"
        return True, ""

    def contains_alnum_and_special(s):
        # Check if a string contains both alphanumeric and special characters.
        has_alnum = any(char.isalnum() for char in s)
        has_special = any(char in string.punctuation for char in s)
        return has_alnum and has_special

    def validate_password_signup(password):
        # Validates the password for signup.
        if len(password) < 6 or len(password) > 30 or password == "Password":
            return False, "Password must be between 6 and 30 characters"
        result = contains_alnum_and_special(password)
        if not result:
            return False, "Passwords must contain a mix of letters, numbers, and special characters."
        return True, ""

    def validate_email_signup(email):
        # Validates the email address for signup.
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if re.match(pattern, email):
            return True, ""
        else:
            return False, "Please enter a valid email address."

    def validate_confirmpw_signup(confirm, password):
        # Checks if the confirm password matches the initial password.
        if password == confirm:
            return True, ""
        else:
            return False, "Passwords do not match."

    def gender_option_picked(gender):
        # Verifies if the user picks an option.
        if gender == "-- Select Your Gender --":
            return False, "Please select a gender option before proceeding."
        else:
            return True, ""

    def terms_and_conditions_checked(terms):
        # Verifies if the user agrees to the terms and conditions.
        if terms == 0:
            return False, "Please agree to the terms and conditions before proceeding."
        else:
            return True, ""

    def on_signup_email_focus_in(event):
        # Clear the placeholder text in the email entry field when it gains focus.
        if signup_email_entry.get() == "Email Address":
            signup_email_entry.delete(0, END)
            signup_email_entry.config(show="")

    def on_signup_email_focus_out(event):
        # Restore the placeholder text in the email entry field if it is empty when losing focus.
        if signup_email_entry.get() == "":
            signup_email_entry.insert(0, "Email Address")
            signup_email_entry.config(show="")

    def on_signup_user_focus_in(event):
        # Clear the placeholder text in the username entry field when it gains focus.
        if signup_user_entry.get() == "Username":
            signup_user_entry.delete(0, END)

    def on_signup_user_focus_out(event):
        # Restore the placeholder text in the username entry field if it is empty when losing focus.
        if signup_user_entry.get() == "":
            signup_user_entry.insert(0, "Username")

    def on_signup_password_focus_in(event):
        # Clear the placeholder text in the password entry field when it gains focus.
        if signup_password_entry.get() == "Password":
            signup_password_entry.delete(0, END)
            signup_password_entry.config(show="")

    def on_signup_password_focus_out(event):
        # Restore the placeholder text in the password entry field if it is empty when losing focus.
        if signup_password_entry.get() == "":
            signup_password_entry.insert(0, "Password")
            signup_password_entry.config(show="")

    def on_signup_confirm_focus_in(event):
        # Clear the placeholder text in the confirm password entry field when it gains focus.
        if signup_confirm_entry.get() == "Password":
            signup_confirm_entry.delete(0, END)
            signup_confirm_entry.config(show="")

    def on_signup_confirm_focus_out(event):
        # Restore the placeholder text in the confirm password entry field if it is empty when losing focus.
        if signup_confirm_entry.get() == "":
            signup_confirm_entry.insert(0, "Password")
            signup_confirm_entry.config(show="")

    def clear_current_signup_window():
        global current_signup_window
        current_signup_window = None

    def on_terms_enter(event):
        # Change Color of "terms and conditions" button on Hover.
        terms_label.config(fg="blue")

    def on_terms_leave(event):
        # Reset color of "terms and conditions" button when not hovered.
        terms_label.config(fg="black")

    def show_terms():
        # Window for terms and conditions
        terms_window = Toplevel(current_signup_window)
        terms_window.title("Terms and Conditions")
        terms_window.geometry("750x350+388+275")
        terms_window.configure(bg="white", padx=20, pady=20)
        terms_window.iconbitmap("icons/RideEaseLogo.ico")

        terms_heading = Label(terms_window, text="Terms and Conditions", font=("Helvetica", 25, "bold"), bg="white", fg="black")
        terms_heading.pack(pady=10)
        terms_text = ScrolledText(terms_window, wrap=WORD, bg="white", fg="black", font=("Helvetica", 10))
        terms_text.pack(expand=1, fill=BOTH, padx=10, pady=10)
        terms_text.insert(END, "Your terms and conditions go here...")
        terms_text.config(state=DISABLED)
        terms_heading = Label(terms_window, text="Terms and Conditions", font=("Helvetica", 25, "bold"), bg="white", fg="black")
        terms_heading.pack(pady=10)
        terms_text = ScrolledText(terms_window, wrap=WORD, bg="white", fg="black", font=("Helvetica", 10))
        terms_text.pack(expand=1, fill=BOTH, padx=10, pady=10)
        terms_text.insert(END, """Privacy Policy

    Personal Information: We collect personal information (such as usernames and email addresses) when users register for an account on our Ride Booking System. This information is used solely for the purpose of providing and improving our service.

    Data Security: We implement a variety of security measures to maintain the safety of your personal information. Your personal information is contained behind secured networks and is only accessible by a limited number of persons who have special access rights to such systems, and are required to keep the information confidential.

    Third Parties: We do not sell, trade, or otherwise transfer to outside parties your personally identifiable information unless we provide users with advance notice.

    Consent: By using our site, you consent to our Privacy Policy.

    Terms of Use

    Acceptance of Terms: By accessing and using our Ride Booking System, you accept and agree to be bound by the terms and provision of the Terms of Use.

    Use of the Service: You agree to use the service for its intended purpose and not for any illicit purposes including, but not limited to, the reverse engineering of the site and/or its processes and the inclusion of such processes or services in a derivative service.

    Account Responsibilities: Users are responsible for maintaining the confidentiality of their login credentials, and are fully responsible for all activities that occur under their account.

    Changes to Terms: We reserve the right to modify these Terms of Use at any time. Your decision to continue to visit and make use of the site after such changes have been made constitutes your formal acceptance of the new Terms of Use.""")
        bold_words = [
            "Privacy Policy", "Personal Information", "Data Security",
            "Third Parties", "Consent", "Terms of Use",
            "Acceptance of Terms", "Use of the Service",
            "Account Responsibilities", "Changes to Terms"
        ]
    conn = connect_db()

    # ---------------------------------------------------------------------------- #
    #                                   FRONTEND                                   #
    # ---------------------------------------------------------------------------- #

    # Signup Window
    current_signup_window = Toplevel(current_signup_window)
    current_signup_window.title("Ride Ease - Sign Up")
    current_signup_window.geometry("925x500+300+200")
    current_signup_window.configure(bg="white")
    current_signup_window.resizable(False, False)
    current_signup_window.iconbitmap("icons/RideEaseLogo.ico")
    current_signup_window.bind("<Destroy>", lambda event: clear_current_signup_window())
    current_signup_window.lift()

    # Signup Logo Image
    signup_logo_image_path = "images/welcome_new.png"
    signup_logo_image = Image.open(signup_logo_image_path)
    signup_logo_image = signup_logo_image.resize((340, 190), Image.LANCZOS)
    signup_logo_photo_image = ImageTk.PhotoImage(signup_logo_image)

    signup_logo_image_label = Label(current_signup_window, image=signup_logo_photo_image, bg="white")
    signup_logo_image_label.image = signup_logo_photo_image
    signup_logo_image_label.place(x=50, y=60)

    # Heading
    signup_heading = Label(current_signup_window, text="Sign up", font=("Microsoft YaHei UI Light", 23, "bold"), bg="white", fg="black")
    signup_heading.place(x=610, y=20)

    # Email Entry Field
    signup_email_entry = Entry(current_signup_window, width=25, fg="black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    signup_email_entry.place(x=580, y=80)
    signup_email_entry.insert(0, "Email Address")
    signup_email_entry.bind("<FocusIn>", on_signup_email_focus_in)
    signup_email_entry.bind("<FocusOut>", on_signup_email_focus_out)

    email_frame = Frame(current_signup_window, width=270, height=2, bg="black")
    email_frame.place(x=580, y=107)

    # Username Entry Field
    signup_user_entry = Entry(current_signup_window, width=25, fg="black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    signup_user_entry.place(x=580, y=130)
    signup_user_entry.insert(0, "Username")
    signup_user_entry.bind("<FocusIn>", on_signup_user_focus_in)
    signup_user_entry.bind("<FocusOut>", on_signup_user_focus_out)

    user_frame = Frame(current_signup_window, width=270, height=2, bg="black")
    user_frame.place(x=580, y=157)

    # Password Entry Field
    signup_password_entry = Entry(current_signup_window, width=25, fg="black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    signup_password_entry.place(x=580, y=180)
    signup_password_entry.insert(0, "Password")
    signup_password_entry.bind("<FocusIn>", on_signup_password_focus_in)
    signup_password_entry.bind("<FocusOut>", on_signup_password_focus_out)
    signup_password_entry.config(show="*")

    password_frame = Frame(current_signup_window, width=270, height=2, bg="black")
    password_frame.place(x=580, y=207)

    # Confirm Password Entry Field
    signup_confirm_entry = Entry(current_signup_window, width=25, fg="black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    signup_confirm_entry.place(x=580, y=230)
    signup_confirm_entry.insert(0, "Password")
    signup_confirm_entry.bind("<FocusIn>", on_signup_confirm_focus_in)
    signup_confirm_entry.bind("<FocusOut>", on_signup_confirm_focus_out)
    signup_confirm_entry.config(show="*")

    confirm_frame = Frame(current_signup_window, width=270, height=2, bg="black")
    confirm_frame.place(x=580, y=257)

    # Gender Selection
    signup_gender_var = StringVar()
    signup_gender_var.set("-- Select Your Gender --")
    signup_gender_dropdown = OptionMenu(current_signup_window, signup_gender_var, "-- Select Your Gender --", "Male", "Female", "Other")
    signup_gender_dropdown.config(width=24, bg="white", fg="black", font=("Microsoft YaHei UI Light", 10), borderwidth=0, highlightthickness=1, highlightbackground="black")
    signup_gender_dropdown.place(x=580, y=280)

    # Terms and Conditions Checkbox
    terms_var = IntVar()
    terms_checkbox = Checkbutton(current_signup_window, text="I agree to the ", variable=terms_var, onvalue=1, offvalue=0, bg="white", fg="black", font=("Microsoft YaHei UI Light", 9), activebackground="white", activeforeground="black")
    terms_checkbox.place(x=580, y=325)

    # Terms and Conditions Button
    terms_label = Label(current_signup_window, text="terms and conditions", font=("Microsoft YaHei UI Light", 9), bg="white", fg="black", cursor="hand2")
    terms_label.place(x=675, y=325)
    terms_label.bind("<Enter>", on_terms_enter)
    terms_label.bind("<Leave>", on_terms_leave)
    terms_label.bind("<Button-1>", lambda event: show_terms())

    # Signup Button
    signup_button = Button(current_signup_window, text="Sign up", font=("Microsoft YaHei UI Light", 13, "bold"), bg="black", fg="white", width=20, pady=10, command=signup_clicked)
    signup_button.place(x=580, y=370)

    # Already have an account
    have_account_label = Label(current_signup_window, text="I have an account", font=("Microsoft YaHei UI Light", 9), bg="white", fg="black", cursor="hand2")
    have_account_label.place(x=625, y=430)
    have_account_label.bind("<Button-1>", clear_current_signup_window)

# Run the main application loop
root = Tk()
root.title("Main Application")
root.geometry("300x200")
signup_button = Button(root, text="Sign Up", command=signup_window_open)
signup_button.pack(pady=50)
root.mainloop()
