import json
import os
import requests
import uuid

# Creation of Parent Class (Vehicle)
class Vehicle:
    def __init__(self, cost_per_km, capacity):
        self.cost_per_km = cost_per_km
        self.capacity = capacity

    def calculate_cost(self, km):
        return 50.00 if km <= 2 else round(50 + (km - 2) * self.cost_per_km, 2)

# Creation of Child Classes (Car, Van, Motorcycle), then overriding cost per km and capacity.
class Car(Vehicle):
    def __init__(self):
        super().__init__(cost_per_km=15, capacity=4)

class Van(Vehicle):
    def __init__(self):
        super().__init__(cost_per_km=30, capacity=8)

class Motorcycle(Vehicle):
    def __init__(self):
        super().__init__(cost_per_km=10, capacity=1)

# Creation of User's Booking Information
class Booking:
    _customer_no = 1

    def __init__(self, user, vehicle, start_location, end_location, km, no=None, booking_id=None):
        if no is not None:
            self.no = no
            Booking._customer_no = max(Booking._customer_no, no + 1)
        else:
            self.no = Booking._customer_no
            Booking._customer_no += 1

        self.booking_id = booking_id if booking_id else str(uuid.uuid4())
        self.user = user
        self.vehicle = vehicle
        self.start_location = start_location
        self.end_location = end_location
        self.km = km
        self.cost = self.vehicle.calculate_cost(km)

    def to_dict(self):
        return {
            'Customer No.': self.no,
            'ID': self.booking_id,
            'Name': self.user,
            'Vehicle': type(self.vehicle).__name__,
            'Start Location': self.start_location,
            'End Location': self.end_location,
            'Distance Travelled': self.km,
            'Total Cost': self.cost,
        }

    @staticmethod
    def save_to_file(booking, filename):
        with open(filename, 'w') as f:
            f.write(json.dumps(booking.to_dict(), indent=4))

    @staticmethod
    def delete_file(filename):
        os.remove(filename)

    @staticmethod
    def from_dict(data):
        vehicle_map = {
            'Car': Car(),
            'Van': Van(),
            'Motorcycle': Motorcycle()
        }
        return Booking(
            user=data['Name'],
            vehicle=vehicle_map[data['Vehicle']],
            start_location=data['Start Location'],
            end_location=data['End Location'],
            km=data['Distance Travelled'],
            no=data['Customer No.'],
            booking_id=data['ID']
        )

    @staticmethod
    def get_coordinates(address, api_key):
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}&key={api_key}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if data['status'] == 'OK':
                lat = data['results'][0]['geometry']['location']['lat']
                lng = data['results'][0]['geometry']['location']['lng']
                return (lat, lng)
            else:
                raise Exception("Invalid address or location.")
        else:
            raise Exception("Failed to get coordinates.")
